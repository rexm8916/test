/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: rm_system
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES
(1,'Kantor Pusat','Jl Wangunsari RT 03 RW 03, Kecamatan Lembang, Kabupaten Bandung Barat, Jawa Barat 40391','-','2026-02-23 16:21:04','2026-02-23 16:33:18'),
(2,'Cabang Sarijadi','Jl Sarijadi Pasar',NULL,'2026-02-23 16:33:35','2026-02-23 16:36:16');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'customer',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES
(1,'Umum (Walk-in)','-','-','2026-02-16 04:07:22','2026-02-16 04:07:22','customer'),
(4,'Warteg Lebak Ningsih',NULL,'Jl cijengkol','2026-02-18 21:43:56','2026-02-18 21:43:56','customer');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debts`
--

DROP TABLE IF EXISTS `debts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `debts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` bigint(20) unsigned NOT NULL,
  `amount_total` decimal(15,2) NOT NULL,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `debts_transaction_id_foreign` (`transaction_id`),
  CONSTRAINT `debts_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debts`
--

LOCK TABLES `debts` WRITE;
/*!40000 ALTER TABLE `debts` DISABLE KEYS */;
INSERT INTO `debts` VALUES
(7,8,417000.00,500000.00,'paid',NULL,'2026-02-18 21:18:28','2026-02-18 21:18:28'),
(8,9,495000.00,500000.00,'paid',NULL,'2026-02-18 21:19:11','2026-02-18 21:19:11'),
(9,11,440000.00,500000.00,'paid',NULL,'2026-02-18 21:33:50','2026-02-18 21:33:50'),
(10,12,440000.00,500000.00,'paid',NULL,'2026-02-18 21:33:53','2026-02-18 21:33:53'),
(11,13,850000.00,500000.00,'partial',NULL,'2026-02-18 21:44:39','2026-02-18 21:44:39'),
(13,15,397000.00,400000.00,'paid',NULL,'2026-02-18 22:08:24','2026-02-18 22:08:24'),
(14,16,3780000.00,3800000.00,'paid',NULL,'2026-02-18 22:15:26','2026-02-18 22:15:26');
/*!40000 ALTER TABLE `debts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `expense_date` date NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_branch_id_foreign` (`branch_id`),
  CONSTRAINT `expenses_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES
(2,'2026-02-22','Operasional','uang bongkar 4 orang',60000.00,'2026-02-22 02:30:52','2026-02-23 17:19:20',1);
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_ledgers`
--

DROP TABLE IF EXISTS `inventory_ledgers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_ledgers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL DEFAULT '2026-02-17',
  `type` varchar(255) NOT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_ledgers_branch_id_foreign` (`branch_id`),
  CONSTRAINT `inventory_ledgers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_ledgers`
--

LOCK TABLES `inventory_ledgers` WRITE;
/*!40000 ALTER TABLE `inventory_ledgers` DISABLE KEYS */;
INSERT INTO `inventory_ledgers` VALUES
(1,'2026-02-17','initial',NULL,NULL,NULL,173802600.00,'2026-02-17 06:48:30','2026-02-23 16:33:56',1),
(5,'2026-02-23','purchase','ST BIRU',1000,14600.00,14600000.00,'2026-02-23 00:09:32','2026-02-23 16:34:09',1),
(6,'2026-02-23','purchase','BAROKAH',500,15000.00,7500000.00,'2026-02-23 00:10:02','2026-02-23 16:34:17',1),
(7,'2026-02-23','purchase','CILILIN',500,13600.00,6800000.00,'2026-02-23 00:10:41','2026-02-23 16:34:26',1),
(8,'2026-02-23','purchase','KETAN PUTIH',50,19000.00,950000.00,'2026-02-23 00:11:13','2026-02-23 16:34:36',1),
(9,'2026-02-23','purchase','MENIR',50,9300.00,465000.00,'2026-02-23 00:11:46','2026-02-23 16:34:45',1),
(10,'2026-02-23','sale',NULL,NULL,NULL,2100000.00,'2026-02-23 00:12:39','2026-02-23 16:34:53',1),
(11,'2026-02-23','sale',NULL,NULL,NULL,2040000.00,'2026-02-23 00:13:00','2026-02-23 16:35:01',1),
(12,'2026-02-23','sale',NULL,NULL,NULL,7725500.00,'2026-02-23 00:13:15','2026-02-23 16:35:09',1),
(16,'2026-02-24','purchase','ST BIRU',1000,14600.00,14600000.00,'2026-02-24 03:39:34','2026-02-24 03:39:34',2),
(17,'2026-02-24','purchase','BAROKAH',500,15000.00,7500000.00,'2026-02-24 03:39:34','2026-02-24 03:39:34',2),
(18,'2026-02-24','purchase','CILILIN',500,13600.00,6800000.00,'2026-02-24 03:39:34','2026-02-24 03:39:34',2),
(19,'2026-02-24','purchase','KETAN PUTIH',50,19000.00,950000.00,'2026-02-24 03:39:34','2026-02-24 03:39:34',2),
(20,'2026-02-24','purchase','MENIR',50,9300.00,465000.00,'2026-02-24 03:39:34','2026-02-24 03:39:34',2),
(21,'2026-02-24','initial',NULL,NULL,NULL,173802600.00,'2026-02-24 03:40:23','2026-02-24 03:40:23',2),
(22,'2026-02-24','sale',NULL,NULL,NULL,2100000.00,'2026-02-24 03:40:55','2026-02-24 03:40:55',2),
(23,'2026-02-24','sale',NULL,NULL,NULL,2040000.00,'2026-02-24 03:41:12','2026-02-24 03:41:12',2),
(24,'2026-02-24','sale',NULL,NULL,NULL,7725500.00,'2026-02-24 03:41:43','2026-02-24 03:41:43',2),
(25,'2026-02-24','sale',NULL,NULL,NULL,6768000.00,'2026-02-24 03:42:07','2026-02-24 03:42:07',2),
(26,'2026-02-24','purchase','PW ST',500,15500.00,7750000.00,'2026-02-24 03:45:53','2026-02-24 03:45:53',2),
(27,'2026-02-24','purchase','RAJA LELE',1000,14600.00,14600000.00,'2026-02-24 03:45:53','2026-02-24 03:45:53',2),
(28,'2026-02-24','purchase','PUTRI AGRI',500,15000.00,7500000.00,'2026-02-24 03:45:53','2026-02-24 03:45:53',2),
(29,'2026-02-24','purchase','MENIR',50,9300.00,465000.00,'2026-02-24 03:45:53','2026-02-24 03:45:53',2),
(30,'2026-02-24','sale',NULL,NULL,NULL,10000000.00,'2026-02-24 10:18:07','2026-02-24 10:18:07',2),
(31,'2026-02-24','purchase','RAJA LELE',50,14600.00,730000.00,'2026-02-24 11:06:26','2026-02-24 11:06:26',2),
(32,'2026-02-24','sale',NULL,NULL,NULL,2891000.00,'2026-02-24 11:07:11','2026-02-24 11:07:11',2),
(33,'2026-02-25','sale',NULL,NULL,NULL,15921700.00,'2026-02-26 11:08:33','2026-02-26 11:09:44',2),
(34,'2026-02-26','sale',NULL,NULL,NULL,16627000.00,'2026-02-26 11:09:16','2026-02-26 11:09:16',2);
/*!40000 ALTER TABLE `inventory_ledgers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_02_15_034446_create_products_table',1),
(5,'2026_02_15_144914_create_customers_table',1),
(6,'2026_02_15_144920_create_transactions_table',1),
(7,'2026_02_15_144921_create_debts_table',1),
(8,'2026_02_15_144922_create_transaction_items_table',1),
(9,'2026_02_15_144923_create_payments_table',1),
(10,'2026_02_16_055712_add_discount_to_transactions_table',1),
(11,'2026_02_16_121941_add_type_to_customers_table',2),
(12,'2026_02_17_133620_create_inventory_ledgers_table',3),
(13,'2026_02_17_142318_change_transaction_date_to_datetime_in_transactions_table',4),
(14,'2026_02_19_042656_add_discount_to_transaction_items_table',5),
(15,'2026_02_19_104507_create_expenses_table',6),
(16,'2026_02_23_223720_create_branches_table',7),
(17,'2026_02_23_223817_add_branch_id_to_users_table',7),
(18,'2026_02_23_223837_add_branch_id_to_inventory_ledgers_table',7),
(19,'2026_02_23_223903_add_role_to_users_table',7),
(20,'2026_02_24_001312_add_branch_id_to_expenses_table',8);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `debt_id` bigint(20) unsigned NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payment_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_debt_id_foreign` (`debt_id`),
  CONSTRAINT `payments_debt_id_foreign` FOREIGN KEY (`debt_id`) REFERENCES `debts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(8,7,500000.00,'2026-02-19','Initial payment','2026-02-18 21:18:28','2026-02-18 21:18:28'),
(9,8,500000.00,'2026-02-19','Initial payment','2026-02-18 21:19:11','2026-02-18 21:19:11'),
(10,9,500000.00,'2026-02-19','Initial payment','2026-02-18 21:33:50','2026-02-18 21:33:50'),
(11,10,500000.00,'2026-02-19','Initial payment','2026-02-18 21:33:53','2026-02-18 21:33:53'),
(12,11,500000.00,'2026-02-19','Initial payment','2026-02-18 21:44:39','2026-02-18 21:44:39'),
(13,13,400000.00,'2026-02-19','Initial payment','2026-02-18 22:08:24','2026-02-18 22:08:24'),
(14,14,3800000.00,'2026-02-19','Initial payment','2026-02-18 22:15:26','2026-02-18 22:15:26');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `buy_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `sell_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(6,'BMW',90,10000.00,15000.00,'2026-02-18 21:01:03','2026-02-18 22:15:26'),
(7,'BMW 25kg',384,400000.00,425000.00,'2026-02-18 21:08:25','2026-02-18 22:15:26'),
(9,'st biru',1000,14600.00,15000.00,'2026-02-22 02:26:51','2026-02-22 02:26:51'),
(10,'Bintang',500,15000.00,15500.00,'2026-02-22 02:27:32','2026-02-22 02:27:32'),
(11,'f3 cililin',500,13600.00,14500.00,'2026-02-22 02:27:57','2026-02-22 02:27:57'),
(12,'ketan putih',50,19000.00,20000.00,'2026-02-22 02:28:21','2026-02-22 02:28:21'),
(13,'menir',50,9300.00,11000.00,'2026-02-22 02:28:39','2026-02-22 02:28:39');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('2aWEaGmHQafvckQlcHCqfOn8aOcDXJQgiW2aZ2oE',NULL,'147.185.133.192','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiV1d0dEpUYWN0Q0FMdlVzU3k4eUhIZ2hMSzlIWjQyR05jU0RwaDlWNSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNjoiaHR0cDovLzIwMy4xOTQuMTE1LjYxOjEwMTAvaW52ZW50b3J5Ijt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwL2ludmVudG9yeSI7czo1OiJyb3V0ZSI7czoxNToiaW52ZW50b3J5LmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1772075764),
('6GLZ18YQAOILiX39a53L7vegkzQ6J4UUhSlUbhW4',3,'114.124.210.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiMVBpUHlGS1lyT1AwT1VmcWpKQ0ZkR3JTYW9Ra1M0ZVVGaTd0c1N1VyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwL2ludmVudG9yeSI7czo1OiJyb3V0ZSI7czoxNToiaW52ZW50b3J5LmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==',1772119389),
('b6L338jhBU9pA9daOE1zFhMAjEMiGK7vQWsoTlfr',NULL,'35.203.210.129','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSUR1YWVQUUFMY2NMdEkyZ3Z0V3VxRUZBR1p3QUxIVUtaSDFjQjQ0VCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1772031151),
('BxTE6w058MkQfIEQPT0NIJjn5pgGduDk3y2tNNcj',NULL,'147.185.132.250','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRGlraU1kU3YxcGkweHZOTDJLMnAxbGhPSzB6RWRxWDJJSWM5c2pBeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1772081688),
('GuGYw6ubibMSH887e4wPUt66TfJMBSfAFifY2NBC',NULL,'35.203.210.129','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiU2FJUTY3blA0OXcwcHZKckhzN2VOVklIS1VnNnhjMFhJTWFoTFNFWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1772031152),
('luWMglaQeK9tj3rk1kdoSXDz16ltVtoJpcJtfORT',NULL,'147.185.133.192','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzl3M1pnR1ZXcUJpNllXWnpuM1l0VFBVeTBDekpjSEFQMmNlQ2xiWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1772075763),
('MnQATJ1A6fhKDmoG2ZB5TjPHpcaoddE9uCOmYVxo',NULL,'35.203.210.129','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiY29oMG9HdnphOGZHdUY2Z3dyTmd4QmFhV280S2s1MUc1Z2l5RHZMNiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNjoiaHR0cDovLzIwMy4xOTQuMTE1LjYxOjEwMTAvaW52ZW50b3J5Ijt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwL2ludmVudG9yeSI7czo1OiJyb3V0ZSI7czoxNToiaW52ZW50b3J5LmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1772031151),
('q63DC0LZrs9MQ5chFJWNSC5hncRPgC7CU29LUOyS',NULL,'147.185.132.250','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRjdtTkIzUzVUbTJIdFV3QVIzUUk0c3UwNkdKb2RMOXlqYkdlR2wwdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1772081687),
('sFYWWOWzfXGzCfK9VAAjxJqBPcY6DhZ5ZyYBKHJX',NULL,'147.185.132.250','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaFpMeVRPSjZ6TW5nWWxzQnJtdmVrOThvWUQ3WXVBWFhkMWVUM051YiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNjoiaHR0cDovLzIwMy4xOTQuMTE1LjYxOjEwMTAvaW52ZW50b3J5Ijt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwL2ludmVudG9yeSI7czo1OiJyb3V0ZSI7czoxNToiaW52ZW50b3J5LmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1772081688),
('TdAMgHoMUGrj46yXLq53KxmJ6oGL68tg7jscsyTY',5,'182.10.97.38','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSUh4QTZnSzlGdmc0UENuclBUUzNBUW92VUxyRFdaRXpKT05SVnE1UCI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NTtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozNjoiaHR0cDovLzIwMy4xOTQuMTE1LjYxOjEwMTAvaW52ZW50b3J5IjtzOjU6InJvdXRlIjtzOjE1OiJpbnZlbnRvcnkuaW5kZXgiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1772104184),
('UrkdLFZbFVM8G8o308CwD1paX2XubpcbMhtvVN58',3,'114.124.240.240','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNml4M2hnenJvU1lYUzRGZllWN2FaSHY3VHEyaVpJYlU3MW1UTDB2QyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTY6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwL3RyYW5zYWN0aW9ucy9jcmVhdGU/dHlwZT1zYWxlIjtzOjU6InJvdXRlIjtzOjE5OiJ0cmFuc2FjdGlvbnMuY3JlYXRlIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==',1772034230),
('Zhz22tRldhE6l4VeeVBGM69znds8MbzfVwabpslp',NULL,'147.185.133.192','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV0pqZ3Uya21nNVlVYVE0Q0RTdnQ5V3B4TGZMbUhBNGY4SmtkZjNqNiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8yMDMuMTk0LjExNS42MToxMDEwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1772075765);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_items`
--

DROP TABLE IF EXISTS `transaction_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_items_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_items_product_id_foreign` (`product_id`),
  CONSTRAINT `transaction_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `transaction_items_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_items`
--

LOCK TABLES `transaction_items` WRITE;
/*!40000 ALTER TABLE `transaction_items` DISABLE KEYS */;
INSERT INTO `transaction_items` VALUES
(9,8,7,1,425000.00,0.00,425000.00,'2026-02-18 21:18:28','2026-02-18 21:18:28'),
(10,9,6,5,15000.00,0.00,75000.00,'2026-02-18 21:19:11','2026-02-18 21:19:11'),
(11,9,7,1,425000.00,0.00,425000.00,'2026-02-18 21:19:11','2026-02-18 21:19:11'),
(12,11,7,1,425000.00,0.00,425000.00,'2026-02-18 21:33:50','2026-02-18 21:33:50'),
(13,11,6,1,15000.00,0.00,15000.00,'2026-02-18 21:33:50','2026-02-18 21:33:50'),
(14,12,7,1,425000.00,0.00,425000.00,'2026-02-18 21:33:53','2026-02-18 21:33:53'),
(15,12,6,1,15000.00,0.00,15000.00,'2026-02-18 21:33:53','2026-02-18 21:33:53'),
(16,13,7,2,425000.00,0.00,850000.00,'2026-02-18 21:44:39','2026-02-18 21:44:39'),
(18,15,7,1,425000.00,28000.00,397000.00,'2026-02-18 22:08:24','2026-02-18 22:08:24'),
(19,16,6,3,15000.00,0.00,45000.00,'2026-02-18 22:15:26','2026-02-18 22:15:26'),
(20,16,7,9,425000.00,10000.00,3735000.00,'2026-02-18 22:15:26','2026-02-18 22:15:26');
/*!40000 ALTER TABLE `transaction_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('purchase','sale') NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `transaction_date` datetime NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'completed',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_customer_id_foreign` (`customer_id`),
  CONSTRAINT `transactions_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES
(8,'sale',1,417000.00,8000.00,'2026-02-19 04:18:28','completed','2026-02-18 21:18:28','2026-02-18 21:18:28'),
(9,'sale',1,495000.00,5000.00,'2026-02-19 04:19:11','completed','2026-02-18 21:19:11','2026-02-18 21:19:11'),
(11,'sale',1,440000.00,0.00,'2026-02-19 04:33:50','completed','2026-02-18 21:33:50','2026-02-18 21:33:50'),
(12,'sale',1,440000.00,0.00,'2026-02-19 04:33:53','completed','2026-02-18 21:33:53','2026-02-18 21:33:53'),
(13,'sale',4,850000.00,0.00,'2026-02-19 04:44:39','completed','2026-02-18 21:44:39','2026-02-18 21:44:39'),
(15,'sale',1,397000.00,0.00,'2026-02-19 05:08:24','completed','2026-02-18 22:08:24','2026-02-18 22:08:24'),
(16,'sale',1,3780000.00,0.00,'2026-02-19 05:15:26','completed','2026-02-18 22:15:26','2026-02-18 22:15:26');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'admin',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_branch_id_foreign` (`branch_id`),
  CONSTRAINT `users_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(3,'Super Admin','superadmin@test.com',NULL,'$2y$12$xcP9kNkmVcZPkIs3F3GYgeInPmDKXEE9CiB.OLf5G0a6K.z5DXxlW','uvvFZM8p72TVR3PsRRXDQdjuB4OMmD9gqn8kqQPt7MMv8P0Z3Rz02OCvhVRe','2026-02-23 16:21:04','2026-02-23 16:22:07',NULL,'superadmin'),
(4,'admin pusat','adminpusat@test.com',NULL,'$2y$12$M8NLjK8JGZjV/l5Se77e7OC18MGyHMWodpbgsMrgrXZpNIjNUIF0C',NULL,'2026-02-23 16:36:55','2026-02-23 16:38:50',1,'admin'),
(5,'admin sarijadi','adminsarijadi@test.com',NULL,'$2y$12$Mfx.kJhrNxRQHXsnswD9Nu3x68J5cN.AmQHjiMTnjPpsR8ztM1CzC','dlXccmISJzpNXSiyU7wyleU9ydtdmWS4pVPx6NucpBbDCJmufiZfIMCbteLp','2026-02-23 16:37:23','2026-02-23 16:39:04',2,'admin');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'rm_system'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-26 22:24:13
